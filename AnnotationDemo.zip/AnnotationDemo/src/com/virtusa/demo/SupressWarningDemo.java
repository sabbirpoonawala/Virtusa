package com.virtusa.demo;

import java.util.ArrayList;
import java.util.List;

public class SupressWarningDemo {

	@SuppressWarnings(value = {"unused","unchecked","rawtypes"})
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List list=new ArrayList();
		list.add(10);
		int i=10;
		

	}

}
