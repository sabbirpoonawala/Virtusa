package com.virtusa.demo;

public class OverrideDemo {
	
	@Override
	public String toString() {
		return "some string representation";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
