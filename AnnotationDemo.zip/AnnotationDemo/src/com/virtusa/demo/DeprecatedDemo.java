package com.virtusa.demo;

public class DeprecatedDemo {
	/***
	 * @author admin
	 * @see x_new
	 * x() has a bug ,may return null in some scenarios
	 */
	@Deprecated
	public void x() {
		System.out.println("-x-");
	}
	public void x_new() {
		System.out.println("-x new-");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DeprecatedDemo d=new DeprecatedDemo();
		d.x();
	}

}
