package com.virtusa.processing;

import com.virtusa.annotation.VirtusaController;
import com.virtusa.annotation.VirtusaService;
import com.virtusa.annotation.VirtusaTable;
import com.virtusa.controller.EmployeeController;
import com.virtusa.entity.Employees;
import com.virtusa.service.EmployeeService;

public class AnnotationProcessingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Class classDataEmployeeController=EmployeeController.class;
		VirtusaController vistusaController=
				(VirtusaController)
				classDataEmployeeController.getAnnotation(VirtusaController.class);
		
		if(vistusaController!=null)
			System.out.println("It is controller class");
		else
			System.out.println("It is not a controller class");
		
		Class classDataEmployeeService=EmployeeService.class;
		VirtusaService virtusaService=
				(VirtusaService)classDataEmployeeService.getAnnotation(VirtusaService.class);
		if(virtusaService!=null) {
			System.out.println("It is service class");
		}else
			System.out.println("It is not a service class");
		
		Class employeeClassData=Employees.class;
		VirtusaTable virtusaTable=
				(VirtusaTable)employeeClassData.getAnnotation(VirtusaTable.class);
		if(virtusaTable!=null) {
			System.out.println("Table Name:"+virtusaTable.tableName());
		}else {
			System.out.println("Not an entity");
		}

	}

}
