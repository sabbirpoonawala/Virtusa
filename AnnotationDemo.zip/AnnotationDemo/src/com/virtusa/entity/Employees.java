package com.virtusa.entity;

import com.virtusa.annotation.VirtusaTable;

@VirtusaTable(tableName = "EMPLOYEES")
public class Employees {

}
