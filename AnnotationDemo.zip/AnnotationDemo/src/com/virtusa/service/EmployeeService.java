package com.virtusa.service;

import com.virtusa.annotation.VirtusaService;

@VirtusaService
public class EmployeeService {

}
