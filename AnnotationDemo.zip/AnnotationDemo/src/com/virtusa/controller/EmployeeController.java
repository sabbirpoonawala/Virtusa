package com.virtusa.controller;

import com.virtusa.annotation.VirtusaController;

@VirtusaController
public class EmployeeController {

}
