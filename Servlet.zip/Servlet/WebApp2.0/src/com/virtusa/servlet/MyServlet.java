package com.virtusa.servlet;

public class MyServlet {

}
