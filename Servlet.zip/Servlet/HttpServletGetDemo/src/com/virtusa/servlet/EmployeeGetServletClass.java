package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmployeeGetServletClass
 */
public class EmployeeGetServletClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeGetServletClass() {
        super();
        // TODO Auto-generated constructor stub
    }
    private Connection connection=null;
    public void init(ServletConfig config){
    	
    	String driver=config.getInitParameter("driver");
    	String url=config.getInitParameter("url");
    	String username=config.getInitParameter("username");
    	String password=config.getInitParameter("password");
    	
    	try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	try {
			connection=DriverManager.getConnection(url,username,password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int employeeId=Integer.parseInt(request.getParameter("employeeId"));
		
		
		PrintWriter out=response.getWriter();
		out.println("<html><head><title>Employee Salary info</title></head>");
		out.println("<body>");
		out.println("<table cellspacing='2' cellpadding='2' border='2'>");
		out.println("<tr>");
		out.println("<th>Full Name</th><th>Salary</th><th>Commission PCT</th>");
		out.println("</tr>");
		try {
			PreparedStatement statement=connection.prepareStatement("select * from employees where employee_id=?");
			statement.setInt(1, employeeId);
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next()) {
				out.println("<tr>");
				out.println("<td>"+resultSet.getString("first_name")+" "+resultSet.getString("last_name")+"</td>");
				out.println("<td>"+resultSet.getDouble("salary")+"</td>");
				out.println("<td>"+resultSet.getDouble("commission_pct")+"</td>");
				out.println("</tr>");
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	
	}
	@Override
	public void destroy() {
		connection=null;
	}

}
