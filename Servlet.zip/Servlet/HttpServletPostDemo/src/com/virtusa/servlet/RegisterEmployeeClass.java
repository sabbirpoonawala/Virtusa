package com.virtusa.servlet;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterEmployeeClass
 */
@WebServlet(name = "RegisterEmployee", urlPatterns = { "/registerEmployee" },
initParams = { 
		@WebInitParam(name = "path", value = "C:\\IO\\DB.properties")
})

public class RegisterEmployeeClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterEmployeeClass() {
        super();
        // TODO Auto-generated constructor stub
    }

    private Connection connection=null;
    @Override
    public void init(ServletConfig config) {
    	
    	String path=config.getInitParameter("path");
    	System.out.println("Path:"+path);
    	try {
			InputStream is=new FileInputStream(path);
			Properties properties=new Properties();
			properties.load(is);
			Class.forName(properties.getProperty("driver"));
			connection=DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("username"),properties.getProperty("password"));
			
		} catch (IOException | ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int employeeId=Integer.parseInt(request.getParameter("employeeId"));
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		double salary=Double.parseDouble(request.getParameter("salary"));
		double commissionPCT=Double.parseDouble(request.getParameter("commissionPCT"));
		
		try {
			PreparedStatement statement=connection.prepareStatement("insert into employees values(?,?,?,?,?)");
			statement.setString(1, firstName);
			statement.setString(2, lastName);
			statement.setDouble(3, salary);
			statement.setDouble(4, commissionPCT);
			statement.setInt(5, employeeId);
			int rows=statement.executeUpdate();
			PrintWriter out=response.getWriter();
			if(rows>0) {
				RequestDispatcher dispatcher=request.getRequestDispatcher("success.jsp");
                dispatcher.forward(request, response);
				//out.println("Registration successful");
				
			}else {
				RequestDispatcher dispatcher=request.getRequestDispatcher("error.jsp");
                dispatcher.forward(request, response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
