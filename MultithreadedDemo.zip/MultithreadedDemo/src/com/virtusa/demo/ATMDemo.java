package com.virtusa.demo;

public class ATMDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ATM atm=new ATM();
		atm.setAtmLocation("Gachibowli");
		atm.setBankName("ICICI Bank");
		
		Customer customer1=new Customer(atm,"Sabbir");
		Customer customer2=new Customer(atm,"Amit");
		Customer customer3=new Customer(atm,"Rohit");
		Customer customer4=new Customer(atm,"Pooja");
		Customer customer5=new Customer(atm,"Manish");
		Customer customer6=new Customer(atm,"Priyanka");
		
		Thread worker1=new Thread(customer1);
		Thread worker2=new Thread(customer2);
		Thread worker3=new Thread(customer3);
		Thread worker4=new Thread(customer4);
		Thread worker5=new Thread(customer5);
		Thread worker6=new Thread(customer6);

		worker1.start();
		worker2.start();
		worker3.start();
		worker4.start();
		worker5.start();
		worker6.start();
		
		

	}

}
