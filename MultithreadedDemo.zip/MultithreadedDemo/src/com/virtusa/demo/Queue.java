package com.virtusa.demo;

public class Queue {
	
	public Queue() {}
	
	
	private int n;
	private boolean valueSet=false;
	
	public synchronized void put(int n) {
		
		if(valueSet) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		this.n=n;
		System.out.println("Put:"+n);
		valueSet=true;
		notify();
	}
	
	public synchronized int get() {
		
		if(!valueSet) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Got:"+n);
		valueSet=false;
		notify();
		return n;
	}

}
