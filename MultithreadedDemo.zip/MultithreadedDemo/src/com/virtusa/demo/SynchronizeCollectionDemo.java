package com.virtusa.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class SynchronizeCollectionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> names=new ArrayList<>();
		names.add("sabbir");
		names.add("amit");
		names.add("sumeet");
		
		Collections.synchronizedList(names);
		
		AtomicInteger o=new AtomicInteger(1);
		System.out.println(o.getAndIncrement());
		System.out.println(o.get());
		
		
	}

}
