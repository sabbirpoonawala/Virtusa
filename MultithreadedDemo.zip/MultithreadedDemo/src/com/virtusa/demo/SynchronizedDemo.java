package com.virtusa.demo;

public class SynchronizedDemo implements Runnable {
	
	private static int counter;
	
	public void increment() {
		while(true) {
			synchronized(SynchronizedDemo.class) {
		counter++;
		System.out.println("current value of counter"+counter);
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		}
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		increment();
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Thread worker1=new Thread(new SynchronizedDemo());
		Thread worker2=new Thread(new SynchronizedDemo());
		worker1.start();
		worker2.start();

	}
	

}
