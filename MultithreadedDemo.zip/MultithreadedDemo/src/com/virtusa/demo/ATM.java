package com.virtusa.demo;

public class ATM {
	
	private String bankName;
	private String atmLocation;
	
	public ATM() {}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getAtmLocation() {
		return atmLocation;
	}

	public void setAtmLocation(String atmLocation) {
		this.atmLocation = atmLocation;
	}
	

}
