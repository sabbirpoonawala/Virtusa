package com.virtusa.demo;

public class ProducerConsumerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Queue queue=new Queue();
		Producer producer1=new Producer(queue);
		Consumer consumer1=new Consumer(queue);
		
		Producer producer2=new Producer(queue);
		Consumer consumer2=new Consumer(queue);
		
		Thread producerWorker1=new Thread(producer1,"producer");
		Thread consumerWorker1=new Thread(consumer1,"consumer");
		
		Thread producerWorker2=new Thread(producer2,"producer");
		Thread consumerWorker2=new Thread(consumer2,"consumer");
		producerWorker1.start();
		consumerWorker1.start();

		producerWorker2.start();
		consumerWorker2.start();
	}

}
