package com.virtusa.demo;

public class Customer implements Runnable{
	private ATM atm;
	private String customerName;
	
	public Customer() {}
	public Customer(ATM atm,String customerName) {
		this.atm=atm;
		this.customerName=customerName;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println(customerName+" customer waiting in a queue");
		synchronized(atm) {
		
			System.out.println(customerName+" entered atm cabin");
			System.out.println(customerName+" started transaction");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(customerName+" exits ATM");

		}
		
		
	}
	
	

}
