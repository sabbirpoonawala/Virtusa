package com.virtusa.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try(
		
				Connection conn=
				DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
		 ){
			
			PreparedStatement st=
					conn.prepareStatement("insert into student_info values(STUDENTSEQ.nextval,?)");
			st.setString(1, "Hemanth");
			int rows=st.executeUpdate();
			if(rows>0)
				System.out.println("Inserted");
			else
				System.out.println("Not inserted");
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

}
