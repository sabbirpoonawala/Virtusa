package com.virtusa.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CallFunctionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try(
				Connection con=
				DriverManager
				.getConnection("jdbc:oracle:thin:@localhost:1521:orcl",
						"hr","hr");
				
	      ){
			
			
			PreparedStatement st=
					con.prepareStatement("select tax_calc(salary) "
							+ "from employees where employee_id=?");
			
			st.setInt(1, 105);
			ResultSet rs=st.executeQuery();
			
			while(rs.next()) {
				System.out.println("Tax:"+rs.getInt(1));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

}
