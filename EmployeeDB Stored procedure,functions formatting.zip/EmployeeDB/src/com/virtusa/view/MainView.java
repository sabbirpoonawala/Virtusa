package com.virtusa.view;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

import com.virtusa.controller.EmployeeController;
import com.virtusa.exception.ValidationException;
import com.virtusa.helper.RequestType;
import com.virtusa.model.EmployeesModel;
import com.virtusa.model.RegisterEmployeesModel;
import com.virtusa.model.UpdateEmployeesModel;
import com.virtusa.validation.EmployeesModelValidator;

public class MainView {
	
	static {
		System.out.println("\t \t Employee Database Application");
		System.out.println("\n");
	}
	public MainView() {
		
	}
	
	public void mainMenu() {
		
		System.out.println("\t \t ========Main Menu========");
		System.out.println("=>1. View Employee Details");
		System.out.println("=>2. View Employee Department");
		System.out.println("=>3. View Employee Job");
		System.out.println("=>4. View Employee Tax");
		System.out.println("=>5. Register Employee");
		System.out.println("=>6. update Employee");
		System.out.println("=>7. Delete Employee");
		System.out.println("=>8. Exit \n");
		try(Scanner scanner=new Scanner(System.in);){
			
			System.out.print("\nOption:");
			int option=scanner.nextInt();
			
			switch(option) {
			
			case 1:viewEmployeeMenu();
			       break;
			case 2:
				   viewEmployeeDepartmentName();
				   break;
			case 3:
				   viewEmployeeJobTitle();
				   break;
			case 4:viewEmployeeTax();
			       break;
			case 5:registerEmployeeForm();
				   break;
			case 6:updateEmployeeSalaryForm();
				   break;
			case 7:deleteEmployeeForm();
				   break;
			case 8:System.exit(0);
			   break;
			default:System.out.println("!ERROR[SELECT APPROPRIATE OPTION]");
			        mainMenu();
				  
			}
			
		}catch(Exception e) {
			
			System.out.println("!ERROR[SELECT APPROPRIATE OPTION]");
		}
		
	}
	
	public void viewEmployeeMenu() {
		
		try(
				Scanner scanner=new Scanner(System.in);
		){
			System.out.println("\n");
			System.out.println("1. View Employees Name");
			System.out.println("2. View Employees Contact");
			System.out.println("3. View Employees Salary");
			System.out.println("4. Main Menu");
			System.out.println("\n");
			
			System.out.print("Enter Option:");
			int option=scanner.nextInt();
			EmployeeController employeeController=new EmployeeController();
			if(option==1)
			employeeController.handleRetrieveEmployees(RequestType.NAME);
		
			if(option==2)
			employeeController.handleRetrieveEmployees(RequestType.CONTACT);
			
			if(option==3)
			employeeController.handleRetrieveEmployees(RequestType.SALARY);
			
            if(option==4)
            	mainMenu();
			
		}catch(Exception e) {
			e.printStackTrace();
		}

	}
	
	public void viewEmployeeDepartmentName() {
		  EmployeeController employeeController=new EmployeeController();
		  
		  try(Scanner scanner=new Scanner(System.in);){
			  System.out.print("Please Enter Employee Id:");
			  int employeeId=scanner.nextInt();
		      employeeController.handleRetrieveDepartmentName(employeeId);
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
	}
	
	public void viewEmployeeJobTitle() {
		  EmployeeController employeeController=new EmployeeController();
		  int employeeId=0;
		  try(Scanner scanner=new Scanner(System.in);){
			  System.out.print("Employee Id:");
				if(scanner.hasNextInt()) {
				employeeId=scanner.nextInt();
				}
				else {
					try {
						throw new ValidationException("[!ERROR:Invalid Employee Id]");
						}catch(ValidationException e) {
							System.out.println(e.getMessage());
							mainMenu();
						}
				}
		      employeeController.handleRetrieveJobTitle(employeeId);
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
	}
	
	public void viewEmployeeTax() {
		  EmployeeController employeeController=new EmployeeController();
		  int employeeId=0;
		  try(Scanner scanner=new Scanner(System.in);){
			  System.out.print("Employee Id:");
				if(scanner.hasNextInt()) {
				employeeId=scanner.nextInt();
				}
				else {
					try {
						throw new ValidationException("[!ERROR:Invalid Employee Id]");
						}catch(ValidationException e) {
							System.out.println(e.getMessage());
							mainMenu();
						}
				}
		      employeeController.handleEmployeeRetrieveTax(employeeId);
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
		  mainMenu();
	}
	
public void registerEmployeeForm() {
		
		try(Scanner scanner=new Scanner(System.in);){
			
			int employeeId=0;
			System.out.print("Employee Id:");
			if(scanner.hasNextInt()) {
			employeeId=scanner.nextInt();
			}
			else {
				try {
					throw new ValidationException("[!ERROR:Invalid Employee Id]");
					}catch(ValidationException e) {
						System.out.println(e.getMessage());
						mainMenu();
					}
			}
			EmployeesModelValidator validator=new EmployeesModelValidator();
			
					
			
			System.out.print("First Name:");
			String firstName=scanner.next();
			
			boolean validfirstName=validator.validString(firstName);
			if(!validfirstName)
				try {
				throw new ValidationException("[!ERROR:Invalid First Name]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
			
			
			System.out.print("Last Name:");
			String lastName=scanner.next();
			
			boolean validLastName=validator.validString(lastName);
			if(!validLastName)
				try {
				throw new ValidationException("[!ERROR:Invalid Last Name]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
			
			
			System.out.print("Email:");
			String email=scanner.next();
			
			boolean validemail=validator.validEmail(email);
			if(!validemail)
				try {
				throw new ValidationException("[!ERRORInvalid Email]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
			
			System.out.print("PhoneNumber:");
			String phoneNumber=scanner.next();
			
			System.out.print("Hire Date(DD/MM/YYYY):");
			String hireDateString=scanner.next();
			
			StringTokenizer tokens=new StringTokenizer(hireDateString,"/");
			
			List<String> tokensList=new ArrayList<>();
			while(tokens.hasMoreTokens()) {
				tokensList.add(tokens.nextToken());
			}
			
			int dayOfMonth=Integer.parseInt(tokensList.get(0));
			int month=Integer.parseInt(tokensList.get(1));
			int year=Integer.parseInt(tokensList.get(2));
			
			LocalDate hireDate=LocalDate.of(year, month-1, dayOfMonth);
			
			System.out.print("Job Id:");
			String jobId=scanner.next();
			boolean validJobId=validator.validJob(jobId);
			if(!validJobId)
				try {
				throw new ValidationException("[!ERROR:Invalid Job Id specified]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
			
			System.out.print("Salary:");
			double salary=scanner.nextDouble();
			
			boolean validsalary=validator.validSalary(salary);
			if(!validsalary)
				try {
				throw new ValidationException("[!ERROR:Invalid Salary]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
			System.out.print("Commission Percentage:");
			double commissionPCT=scanner.nextDouble();
			
			System.out.print("Manager Id:");
			int managerId=scanner.nextInt();
			boolean validManagerId=validator.validManagerId(managerId);
			if(!validManagerId)
				try {
				throw new ValidationException("[!ERROR:Invalid No such manager]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
			
			System.out.print("Department Id:");
			int departmentId=scanner.nextInt();
			boolean validDepartmentId=validator.validDepartment(departmentId);
			if(!validDepartmentId)
				try {
				throw new ValidationException("[!ERROR:Invalid Department Id specified]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
			
			RegisterEmployeesModel model=new RegisterEmployeesModel();
			model.setEmployeeId(employeeId);
			model.setFirstName(firstName);
			model.setLastName(lastName);
			model.setEmail(email);
			model.setPhoneNumber(phoneNumber);
			model.setHireDate(hireDate);
			model.setSalary(salary);
			model.setJobId(jobId);
			model.setCommissionPCT(commissionPCT);
			model.setManagerId(managerId);
			model.setDepartmentId(departmentId);
			
			EmployeeController controller=new EmployeeController();
			controller.handleRegisterEmployee(model);
			
		   mainMenu();
		}catch(Exception e) {
			
		}
		
		
	}

public void updateEmployeeSalaryForm() {
	
	try(Scanner scanner=new Scanner(System.in);){
		
		int employeeId=0;
		System.out.print("Employee Id:");
		if(scanner.hasNextInt()) {
		employeeId=scanner.nextInt();
		}
		else {
			try {
				throw new ValidationException("[!ERROR:Invalid Employee Id]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
		}
		EmployeesModelValidator validator=new EmployeesModelValidator();
		System.out.print("New Salary:");
		double salary=scanner.nextDouble();
		
		boolean validsalary=validator.validSalary(salary);
		if(!validsalary)
			try {
			throw new ValidationException("[!ERROR:Invalid Salary]");
			}catch(ValidationException e) {
				System.out.println(e.getMessage());
				mainMenu();
			}
		
		UpdateEmployeesModel model=new UpdateEmployeesModel();
		model.setEmployeeId(employeeId);
		model.setNewSalary(salary);
		EmployeeController controller=new EmployeeController();
		controller.handleUpdateEmployeesSalary(model);
		
	   mainMenu();
	}catch(Exception e) {
		System.out.println("!Error processing request. Please try again later");
	}
}

public void deleteEmployeeForm() {
	
	try(Scanner scanner=new Scanner(System.in);){
		
		int employeeId=0;
		System.out.print("Employee Id:");
		if(scanner.hasNextInt()) {
		employeeId=scanner.nextInt();
		}
		else {
			try {
				throw new ValidationException("[!ERROR:Invalid Employee Id]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
		}
		
		EmployeesModel model=new EmployeesModel();
		model.setEmployeeId(employeeId);
		EmployeeController controller=new EmployeeController();
		controller.handleDeleteEmployees(model);
	    mainMenu();
	}catch(Exception e) {
		System.out.println("[!Error processing request. Please try again later]");
	}
}
	}


