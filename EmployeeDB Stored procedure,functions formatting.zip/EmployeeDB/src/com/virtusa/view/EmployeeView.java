package com.virtusa.view;

import java.util.List;
import com.virtusa.model.EmployeesModel;
import com.virtusa.model.RegisterEmployeesModel;
import com.virtusa.model.UpdateEmployeesModel;

public class EmployeeView {
	
	private MainView mainView=new MainView();
	
	public void showDepartmentName(EmployeesModel models) {
		System.out.println("\n");
		System.out.printf("%-20s %s", "Employee Id", "Department Name");
		System.out.println("\n");
		System.out.printf("%-20s %s", models.getEmployeeId(),models.getDepartmentsModel().getDepartmentName());
		System.out.println("\n");
		mainView.mainMenu();
	}
	public void showEmployeeName(List<EmployeesModel> models) {

		System.out.printf("%-20s %s", "Employee Id", "Employee Name");
		System.out.println("\n");
		for(EmployeesModel model:models) {
			System.out.printf("%-20s %s", model.getEmployeeId(), model.getFullName());
			System.out.println("\n");
			
		}	
	}
	
	public void showEmployeeContact(List<EmployeesModel> models) {
		System.out.printf("%-20s %s", "Employee Id", "Phone Number,Email Address");
		System.out.println("\n");
		for(EmployeesModel model:models) {
			System.out.printf("%-20s %s",model.getEmployeeId(),model.getContactDetails());
			System.out.println("\n");
		}
		
	}
	public void showEmployeeTaxOnSalary(List<EmployeesModel> models) {
		System.out.printf("%-20s %s %s", "Employee Id", "Salary","Tax");
		System.out.println("\n");
		for(EmployeesModel model:models) {
			System.out.printf("%-20s %s %s",model.getEmployeeId(),model.getTotalSalary(),model.getTax());
			System.out.println("\n");
		}
		
	}
	public void showEmployeeSalary(List<EmployeesModel> models) {
		System.out.printf("%-20s %s", "Employee Id", "Total Salary");
		System.out.println("\n");
		for(EmployeesModel model:models) {
			System.out.printf("%-20s %s", model.getEmployeeId(), model.getTotalSalary());
			System.out.println("\n");
		}
		
	}
	
	public void showEmployeeTitle(EmployeesModel model) {
		System.out.println("\n");
		System.out.printf("%-20s %s", "Employee Id", "Job Title");
		System.out.println("\n");
		System.out.printf("%-20s %s", model.getEmployeeId(), model.getJobsModel().getJobTitle());
		System.out.println("\n");
		mainView.mainMenu();
		}

	public void showEmployeeTax(EmployeesModel model) {
		System.out.println("\n");
		System.out.printf("%-20s %s %s", "Employee Id", "Salary","Tax");
		System.out.println("\n");
		System.out.printf("%-20s %s %s", model.getEmployeeId(), model.getTotalSalary(),model.getTax());
		System.out.println("\n");
		mainView.mainMenu();
		}
	
	public void showRegistrationSuccess(RegisterEmployeesModel model) {
		
		System.out.println("\n Registration successful for employee id=>"+model.getEmployeeId());
		mainView.mainMenu();
	}
	
	public void showRegistrationFailure(RegisterEmployeesModel model) {
		System.out.println("\n Registration unsuccessful for employee id=>"+model.getEmployeeId());
		mainView.mainMenu();
	}
	
   public void showSalaryUpdateSuccess(UpdateEmployeesModel model) {
		System.out.println("\n Salary successfully updated for employee id=>"+model.getEmployeeId());
		mainView.mainMenu();
	}
	
	public void showSalaryUpdateFailure(UpdateEmployeesModel model) {
		System.out.println("\n Salary updated failed for employee id=>"+model.getEmployeeId());
		mainView.mainMenu();
	}

	public void showDeleteSuccess(EmployeesModel model){
		System.out.println("\n Employee record deleted for employee id=>"+model.getEmployeeId());
			
	}
	  public void showDeleteFailure(EmployeesModel model){
			System.out.println("\n Employee record deletion failed for employee id=>"+model.getEmployeeId());	
	}	
	
	  public void validationFailedError() {
		  System.out.println("Data validation failed!!");
	  }
}