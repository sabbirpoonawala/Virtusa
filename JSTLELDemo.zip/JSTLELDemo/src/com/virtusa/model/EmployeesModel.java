package com.virtusa.model;

public class EmployeesModel {
	
	private String firstName;
	private String lastName;
	
	public EmployeesModel() {}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	

}
