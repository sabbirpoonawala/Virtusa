package com.virtusa.view;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

import com.virtusa.controller.EmployeeController;
import com.virtusa.model.EmployeesModel;
import com.virtusa.model.RegisterEmployeesModel;

public class EmployeeView {
	
	private MainView mainView=new MainView();
	
	public void showDepartmentName(EmployeesModel models) {
		
		System.out.println("Deparment Name:"+models.getDepartmentsModel().getDepartmentName()+"\n");
		mainView.mainMenu();
	}
	
	public void showEmployeeName(List<EmployeesModel> models) {
		for(EmployeesModel model:models) {
			System.out.println(model.getFullName()+"\n");
		}
		
	}
	
	public void showEmployeeContact(List<EmployeesModel> models) {
		for(EmployeesModel model:models) {
			System.out.println(model.getContactDetails()+"\n");
		}
		
	}
	
	public void showEmployeeSalary(List<EmployeesModel> models) {
		for(EmployeesModel model:models) {
			System.out.println(model.getTotalSalary()+"\n");
		}
		
	}
	
	public void showRegistrationSuccess(RegisterEmployeesModel model) {
		
		System.out.println("Registration successful for employee id"+model.getEmployeeId());
		mainView.mainMenu();
	}
	
	public void showRegistrationFailure(RegisterEmployeesModel model) {
		System.out.println("Registration unsuccessful for employee id"+model.getEmployeeId());
		mainView.mainMenu();
	}
	
	public void validationFailedError() {
		System.out.println("Data entered not valid");
		
	}
	
	

}
