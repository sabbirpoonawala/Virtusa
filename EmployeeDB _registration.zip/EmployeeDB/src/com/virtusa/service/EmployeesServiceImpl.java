package com.virtusa.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.dao.EmployeesDAO;
import com.virtusa.entities.Departments;
import com.virtusa.entities.Employees;
import com.virtusa.exception.SalaryNotValidException;
import com.virtusa.helper.FactoryEmployeeDB;
import com.virtusa.model.DepartmentsModel;
import com.virtusa.model.EmployeesModel;
import com.virtusa.model.RegisterEmployeesModel;

public class EmployeesServiceImpl implements EmployeesService {

	private EmployeesDAO employeesDAO;
	
	public EmployeesServiceImpl() {
		this.employeesDAO=FactoryEmployeeDB.createEmployeesDAO();
		
	}
	@Override
	public List<EmployeesModel> retrieveEmployees() {
		// TODO Auto-generated method stub
		List<EmployeesModel> employeesModelList=new ArrayList<>();
		try {
			List<Employees> employeesList=employeesDAO.getAllEmployees();
			for(Employees employees:employeesList) {
				
				EmployeesModel employeesModel=new EmployeesModel();
				employeesModel.setFullName(employees.getFirstName()+" "+employees.getLastName());
				employeesModel.setTotalSalary(employees.getSalary()+employees.getSalary()*employees.getCommissionPCT());				
				employeesModel.setContactDetails(employees.getPhoneNumber()+","+employees.getEmail());
				employeesModelList.add(employeesModel);
				
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return employeesModelList;
	}
	@Override
	public EmployeesModel retrieveDepartmentName(int employeeId) {
		// TODO Auto-generated method stub
		Employees employees=null;
		EmployeesModel employeesModel=new EmployeesModel();
		try {
			employees=employeesDAO.getDeparmentName(employeeId);
			Departments departments=employees.getDepartments();
			DepartmentsModel departmentModel=new DepartmentsModel();
			departmentModel.setDepartmentName(departments.getDepartmentName());
			employeesModel.setDepartmentsModel(departmentModel);
		
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return employeesModel;
	}
	@Override
	public String registerEmployee(RegisterEmployeesModel model) {
		// TODO Auto-generated method stub
		
		Employees employees=new Employees();
		employees.setEmployeeId(model.getEmployeeId());
		employees.setFirstName(model.getFirstName());
		employees.setLastName(model.getLastName());
		employees.setEmail(model.getEmail());
		employees.setPhoneNumber(model.getPhoneNumber());
		employees.setHireDate(model.getHireDate());
		employees.setJobId(model.getJobId());
		
		if(model.getSalary()>25000) {
			employees.setSalary(model.getSalary());
		}else {
			try {
			throw new SalaryNotValidException("Salary not valid");
			}catch(SalaryNotValidException e) {
				System.out.println("Salary must be greater than 25000");
			}
		}
			
		employees.setCommissionPCT(model.getCommissionPCT());
		employees.setManagerId(model.getManagerId());
		employees.setDepartmentId(model.getDepartmentId());
		String result="fail";
		try {
			boolean stored=employeesDAO.storeEmployeeDetails(employees);
			if(stored)
				result="success";
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Registration failed because of internal issues...");
		}
		return result;
	}

}
