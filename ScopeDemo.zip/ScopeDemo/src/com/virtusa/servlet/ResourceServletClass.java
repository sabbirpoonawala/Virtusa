package com.virtusa.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ResourceServletClass
 */
@WebServlet(
		name = "ResourceServlet", 
		urlPatterns = { "/resource" }, 
		initParams = { 
				@WebInitParam(name = "path", value = "C:\\IO\\DB.properties", description = "database connection info")
		})
public class ResourceServletClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResourceServletClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
    
    private Connection conn=null;
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		String path=config.getInitParameter("path");
		File file=new File(path);
		try(
				InputStream is=new FileInputStream(file);
		){
			Properties properties=new Properties();
			properties.load(is);
			Class.forName(properties.getProperty("driver"));
			conn=DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("username"),properties.getProperty("password"));
			
			
		}catch(IOException | ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		ServletContext sc=getServletContext();
		sc.setAttribute("conn",conn);
		
		RequestDispatcher dispatcher=
				request.getRequestDispatcher("Login.html");
		
		dispatcher.forward(request, response);
	}

}
