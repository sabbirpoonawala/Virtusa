package com.virtusa.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class DeleteEmployeeClass
 */
@WebServlet(name = "DeleteEmployee", urlPatterns = { "/deleteEmployee" })
public class DeleteEmployeeClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteEmployeeClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session=request.getSession(false);
		try {
		String username=(String)session.getAttribute("username");
		username.toUpperCase();
		}catch(NullPointerException e) {
			RequestDispatcher dispatcher=
					request.getRequestDispatcher("sessionexpired.html");
			dispatcher.forward(request, response);
		}
		
	int employeeId=(Integer)request.getAttribute("employeeId");
	ServletContext sc=getServletContext();
	Connection connection=(Connection)sc.getAttribute("conn");
	try {
		PreparedStatement statement=connection.prepareStatement("delete from employees where employee_id=?");
		statement.setInt(1, employeeId);
		int rows=statement.executeUpdate();
		if(rows>0) {
			RequestDispatcher dispatcher=
					request.getRequestDispatcher("success.jsp");
			dispatcher.forward(request, response);
		}else {
			RequestDispatcher dispatcher=
					request.getRequestDispatcher("error.jsp");
			dispatcher.forward(request, response);
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}

}
