package com.virtusa.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.virtusa.entities.Employees;

public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Integer> setInteger=new HashSet<>();
		System.out.println(setInteger.add(10));
		System.out.println(setInteger.add(20));
		System.out.println(setInteger.add(30));
		System.out.println(setInteger.add(40));
		System.out.println(setInteger.add(10));
		
		System.out.println(setInteger);
		
		//java 5
		for(Integer o:setInteger) {
			System.out.println(o);
		}
		

		for(Iterator<Integer> iterator=
				setInteger.iterator();
				iterator.hasNext();) {
			
			System.out.println(iterator.next());

		}
		
		//java 8
		setInteger.forEach((o)->{
			System.out.println(o);
		});
		
		//java 8
		setInteger.forEach(System.out::println);
		
		Set<Employees> setEmployees=new HashSet<>();
		setEmployees.add(
				new Employees(101,"sabbir","poonawala",34000));
		setEmployees.add(
				new Employees(101,"sabbir","poonawala",34000));
		
		
		System.out.println(setEmployees);
	}

}
