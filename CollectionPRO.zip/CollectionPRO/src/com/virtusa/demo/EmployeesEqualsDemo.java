package com.virtusa.demo;

import java.util.ArrayList;

import com.virtusa.entities.Employees;

public class EmployeesEqualsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employees employees1=
				new Employees(101,"sabbir","poonawala",34000);

		System.out.println(employees1);
		
		Employees employees2=
				new Employees(101,"sabbir","poonawala",34000);
		
	
		if(employees1==employees2)
			System.out.println("employees1==employees2");
		if(employees1.equals(employees2))
			System.out.println("employees1.equals(employees2)");
		
		System.out.println("Hash code of employees1:"+employees1.hashCode());
		System.out.println("Hash code of employees2:"+employees2.hashCode());

		
	}

}
