package com.virtusa.list;

public class Box<T> {
	
	private T field;

	public T getField() {
		return field;
	}

	public void setField(T field) {
		this.field = field;
	}
	
	

}
