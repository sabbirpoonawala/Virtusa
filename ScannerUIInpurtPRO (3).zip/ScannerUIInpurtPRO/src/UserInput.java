import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class UserInput {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		Scanner scanner=new Scanner(System.in);
		System.out.print("User Name:");
		
		if(scanner.hasNext()) {
			String userName=scanner.next();
			System.out.println("User Name:"+userName);
		}
		
		System.out.print("First Name:");
		
		
		Set<Character> alphabets=new HashSet<>();
		//ascii value of a=97, z=122
		for(int i=97;i<=122;i++) {
			alphabets.add((char)i);
		}
		
	System.out.println(alphabets);
		if(scanner.hasNext()) {
			String firstName=scanner.next();
			
			if(firstName.matches(".*[a-z][A-z]")) {
				System.out.println("Ok");
			}else {
				System.out.println("invalid");
			}
			
			char firstNameArray[]=firstName.toCharArray();
			
			for(char ch:firstNameArray) {
				if(alphabets.contains(ch)) {
					continue;
				}else {
					System.out.println("invalid name");
					break;
				}
				
			}
			
		}
		
		System.out.print("Salary :");
		if(scanner.hasNextDouble()) {
		double salary=scanner.nextDouble();
		
		System.out.println("Salary:"+salary);
		}else {
			System.out.println("Salary has to be a number");
		}
		

	}

}
