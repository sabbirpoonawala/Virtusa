package com.virtusa.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.helper.FactoryEmployeeDB;
import com.virtusa.model.DepartmentsModel;
import com.virtusa.model.EmployeesModel;
import com.virtusa.service.DepartmentsService;
import com.virtusa.service.EmployeesService;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("/employee")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeesService employeeService=null;
    private DepartmentsService departmentService=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeController() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
    	super.init(config);
    	this.employeeService=FactoryEmployeeDB.createEmployeesService();
    	this.departmentService=FactoryEmployeeDB.createDepartmentsService();
    	
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String action=request.getParameter("action");
		if(action.contentEquals("fullname")) {
		List<EmployeesModel> employeesModelList=employeeService.retrieveEmployees();
		request.setAttribute("employeesModelList", employeesModelList);
		
		if(!employeesModelList.isEmpty()) {
			
			RequestDispatcher dispatcher=
					request.getRequestDispatcher("employeefullnamedetails.jsp");
			dispatcher.forward(request,response);
		}else {
			RequestDispatcher dispatcher=
					request.getRequestDispatcher("noemployeedetails.jsp");
			dispatcher.forward(request,response);
		}
		}
		
		if(action.contentEquals("contact")) {
			List<EmployeesModel> employeesModelList=employeeService.retrieveEmployees();
			request.setAttribute("employeesModelList", employeesModelList);
			
			if(!employeesModelList.isEmpty()) {
				
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("employeecontactdetails.jsp");
				dispatcher.forward(request,response);
			}else {
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("noemployeedetails.jsp");
				dispatcher.forward(request,response);
			}
			}
		
		if(action.contentEquals("salary")) {
			List<EmployeesModel> employeesModelList=employeeService.retrieveEmployees();
			request.setAttribute("employeesModelList", employeesModelList);
			
			if(!employeesModelList.isEmpty()) {
				
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("employeesalarydetails.jsp");
				dispatcher.forward(request,response);
			}else {
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("noemployeedetails.jsp");
				dispatcher.forward(request,response);
			}
			}
		
		if(action.contentEquals("loadform")) {
			
			List<DepartmentsModel> departmentsList=
					departmentService.retrieveDepartments();
			request.setAttribute("departmentsList", departmentsList);
			
			RequestDispatcher dispatcher=
					request.getRequestDispatcher("employeeform.jsp");
			dispatcher.forward(request, response);
		}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
