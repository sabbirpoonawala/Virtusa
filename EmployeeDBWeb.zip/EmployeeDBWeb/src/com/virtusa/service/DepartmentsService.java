package com.virtusa.service;

import java.util.List;

import com.virtusa.model.DepartmentsModel;

public interface DepartmentsService {
	public List<DepartmentsModel> retrieveDepartments();

}
