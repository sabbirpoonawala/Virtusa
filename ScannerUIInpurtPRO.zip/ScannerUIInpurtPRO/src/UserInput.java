import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class UserInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.print("User Name:");
		
		if(scanner.hasNext()) {
			String userName=scanner.next();
			System.out.println("User Name:"+userName);
		}
		
		System.out.print("First Name:");
		
		
		Set<Character> alphabets=new HashSet<>();
		alphabets.add('a');
		alphabets.add('b');
		alphabets.add('c');
		alphabets.add('d');
		alphabets.add('e');
		alphabets.add('f');
		alphabets.add('g');
		alphabets.add('h');
		alphabets.add('i');
		alphabets.add('j');
		alphabets.add('k');
		alphabets.add('l');
		alphabets.add('m');
		alphabets.add('n');
		alphabets.add('o');
		alphabets.add('p');
		alphabets.add('q');
		alphabets.add('r');
		alphabets.add('s');
		alphabets.add('t');
		alphabets.add('u');
		alphabets.add('v');
		alphabets.add('w');
		alphabets.add('x');
		alphabets.add('y');
		alphabets.add('z');
		
	
		if(scanner.hasNext()) {
			String firstName=scanner.next();
			
			if(firstName.matches(".*[a-z][A-z]")) {
				System.out.println("Ok");
			}else {
				System.out.println("invalid");
			}
			
			char firstNameArray[]=firstName.toCharArray();
			
			for(char ch:firstNameArray) {
				if(alphabets.contains(ch)) {
					continue;
				}else {
					System.out.println("invalid name");
					break;
				}
				
			}
			
		}
		
		System.out.print("Salary :");
		if(scanner.hasNextDouble()) {
		double salary=scanner.nextDouble();
		
		System.out.println("Salary:"+salary);
		}else {
			System.out.println("Salary has to be a number");
		}
		

	}

}
