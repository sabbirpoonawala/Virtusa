package com.virtusa.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterEmployeeBean {

	public RegisterEmployeeBean() {}
	
	private int employeeId;
	private String firstname;
	private String lastname;
	private double salary;
	private double commissionPCT;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public double getCommissionPCT() {
		return commissionPCT;
	}
	public void setCommissionPCT(double commissionPCT) {
		this.commissionPCT = commissionPCT;
	}
	
	public boolean insertDetails() {
		
		boolean result=false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
			PreparedStatement st=
					con.prepareStatement("insert into employees values(?,?,?,?,?)");
			st.setString(1, firstname);
			st.setString(2, lastname);
			st.setDouble(3, salary);
			st.setDouble(4, commissionPCT);
			st.setInt(5, employeeId);
			
			int rows=st.executeUpdate();
			if(rows>0)
				result=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
}
