/**
 * 
 */

function changeButtonLabel(){
	
	var button=document.getElementById("b1");
	button.setAttribute("value","Clicked");
	
}

function changeColor(id){
	
	if(id=="red"){
		document.body.bgColor="red";
	}
	if(id=="green"){
		document.body.bgColor="green";
	}
	if(id=="blue"){
		document.body.bgColor="blue";
	}
	
	
	
	
}