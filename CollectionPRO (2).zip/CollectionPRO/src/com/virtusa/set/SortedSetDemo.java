package com.virtusa.set;

import java.util.SortedSet;
import java.util.TreeSet;

import com.virtusa.entities.Employees;

public class SortedSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SortedSet<Integer> sortedSet=new TreeSet<>();
		sortedSet.add(30);
		sortedSet.add(20);
		sortedSet.add(40);
		sortedSet.add(10);
		System.out.println(sortedSet);
		
		SortedSet<String> sortedSetString=new TreeSet<>();
		sortedSetString.add("chirag");
		sortedSetString.add("amit");
		sortedSetString.add("rohit");
		sortedSetString.add("sachin");
		sortedSetString.add("sabbir");
		sortedSetString.add("Mahesh");
		System.out.println(sortedSetString);
		
		SortedSet<Employees> sortedSetEmployees
		=new TreeSet<>();
		
		sortedSetEmployees.add(new Employees(102,"sabbir","poonawala",23000));
		sortedSetEmployees.add(new Employees(101,"amit","gupta",93000));
		sortedSetEmployees.add(new Employees(103,"rohit","patel",20000));
		sortedSetEmployees.add(new Employees(99,"amrish","shah",23000));

		
		System.out.println(sortedSetEmployees);
		
	}

}
