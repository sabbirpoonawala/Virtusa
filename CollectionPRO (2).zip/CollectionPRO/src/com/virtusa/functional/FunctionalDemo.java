package com.virtusa.functional;

public class FunctionalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ComputeInterface impl1=
				new OuterComputeInterfaceImpl();
		System.out.println("Impl1:"+impl1.compute(10, 5));
		
		ComputeInterface impl2=new OuterComputeInterfaceImpl()
		.new InnerComputeInterfaceImpl();
		System.out.println("Impl2:"+impl2.compute(10, 5));
		
		
		ComputeInterface impl3=new ComputeInterface() {
			
			@Override
			public double compute(double a,double b) {
				return a*b;
			}
			
			
		};
		
		System.out.println("impl3:"+impl3.compute(10, 5));


	}

}
