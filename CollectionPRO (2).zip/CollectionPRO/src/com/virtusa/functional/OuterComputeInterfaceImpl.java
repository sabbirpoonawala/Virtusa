package com.virtusa.functional;

public class OuterComputeInterfaceImpl implements ComputeInterface{

	@Override
	public double compute(double a, double b) {
		// TODO Auto-generated method stub
		return a+b;
	}
	
	
	class InnerComputeInterfaceImpl implements ComputeInterface{

		@Override
		public double compute(double a, double b) {
			// TODO Auto-generated method stub
			return a-b;
		}
		
		
	}

}
