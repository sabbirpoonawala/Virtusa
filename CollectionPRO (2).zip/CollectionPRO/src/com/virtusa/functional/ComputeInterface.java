package com.virtusa.functional;
@FunctionalInterface
public interface ComputeInterface {
	
	double compute(double a,double b);

}
