package com.virtusa.functional;

public class LambdaExpressionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ComputeInterface impl1=(a,b)->a+b;
		System.out.println("impl1:"+impl1.compute(10, 5));
		
		ComputeInterface impl2=(a,b)->a-b;
		
		System.out.println("impl2:"+impl2.compute(10, 5));
		
	    ComputeInterface impl3=(a,b)->a*b;
		
		System.out.println("impl3:"+impl3.compute(10, 5));
		
		ComputeInterface impl4=(a,b)->{
			
			System.out.println("--block within lambda--");
			return a/b;
		};
		System.out.println("impl4:"+impl4.compute(10, 5));

	}

}
