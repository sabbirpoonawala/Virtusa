package com.virtusa.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.virtusa.entities.Employees;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map<Integer,String> mapString= new HashMap<>();
		System.out.println(mapString.put(1,"sabbir"));
		System.out.println(mapString.put(2,"amit"));
		System.out.println(mapString.put(3,"sabbir"));
		System.out.println(mapString.put(1,"amit"));
		
		System.out.println(mapString);
		
		Set<Entry<Integer,String>> entries=
				mapString.entrySet();
		
		Iterator<Entry<Integer,String>> iterator=
				entries.iterator();
		
		while(iterator.hasNext()) {
			
			Entry<Integer,String> entry=iterator.next();
			if(entry.getKey()==2)
				System.out.println(entry.getValue());
		}


		//java 8
		mapString.forEach((k,v)->{
			
			System.out.println("Key:"+k);
			System.out.println("value:"+v);
		});

		Map<Integer,Employees> mapEmployees=
				new HashMap<>();
		mapEmployees.put(101,new Employees(101,"sabbir","poonawala",34000));
		mapEmployees.put(102,new Employees(102,"amit","gupta",14000));
        
		mapEmployees.forEach((k,v)->{
			
			System.out.println("Key:"+k);
			System.out.println("value:"+v);
		});

		
	}

}
