package com.virtusa.comparator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.virtusa.entities.Employees;

public class ComparatorDemo {
	
	class EmployeesComparatorByFirstName 
	implements Comparator<Employees>{

		@Override
		public int compare(Employees o1, Employees o2) {
			// TODO Auto-generated method stub
			return o1.getFirstName()
					.compareTo(o2.getFirstName());
		}
		
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employees e1=new Employees(101,"sabbir","poonawala",25000);
		Employees e2=new Employees(99,"amit","gupta",5000);
		Employees e3=new Employees(102,"rohit","patel",12000);


		
		List<Employees> empList=new ArrayList<>();
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		
		Collections.sort(empList, 
				new EmployeesComparatorByEmployeesId());
		
		for(Employees employees:empList) {
			System.out.println(employees);
		}
		
			System.out.println("****sort by first name***");
		Collections.sort(empList,new ComparatorDemo()
				.new EmployeesComparatorByFirstName());
		
		for(Employees employees:empList) {
			System.out.println(employees);
		}
		
		
		System.out.println("****sort by last name***");
		
		Collections.sort(empList,
				new Comparator<Employees>() {
			@Override
			public int compare(Employees o1,Employees o2) {
			 return o1.getLastName().compareTo(o2.getLastName());
			}
		       });
		
		for(Employees employees:empList) {
			System.out.println(employees);
		}
		
		System.out.println("***sort by salary***");
		
Collections.sort(empList,(emp1,emp2)->{			
			if(emp1.getSalary()>emp2.getSalary()){
				return 1;
			}else if(emp1.getSalary()<emp2.getSalary()){
				return -1;
			}else {
				return 0;
			}
			
		});
for(Employees employees:empList) {
	System.out.println(employees);
}
	}

}
