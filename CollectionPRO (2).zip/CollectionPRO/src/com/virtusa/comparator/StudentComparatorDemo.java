package com.virtusa.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.virtusa.entities.Student;

public class StudentComparatorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student();
		s1.setRollNo(101);
		s1.setName("badri");
		s1.setMarks1(75);
		s1.setMarks2(60);
		s1.setMarks3(80);
		Student s2=new Student();
		s2.setRollNo(102);
		s2.setName("sai");
		s2.setMarks1(55);
		s2.setMarks2(40);
		s2.setMarks3(66);
		List<Student> studentList=new ArrayList();
		studentList.add(s1);
		studentList.add(s2);
		Collections.sort(studentList,
				new StudentComparatorByRollNo());
		System.out.println("***sort by rollno");
		for(Student student:studentList) {
			System.out.println(student);
		}
		Collections.sort(studentList,(std1,std2)->{
			if(std1.getRollNo()>std2.getRollNo()) {
				return 1;
			}
			else if(std1.getRollNo()<std2.getRollNo()) {
				return -1;
			}
			else {
				return 0;
			}
		});
		for(Student student:studentList) {
			System.out.println(student);
		}
	}

}
