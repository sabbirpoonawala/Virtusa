package com.virtusa.comparator;

import java.util.Comparator;

import com.virtusa.entities.Student;

public class StudentComparatorByRollNo implements Comparator<Student> {

	@Override
	public int compare(Student o1, Student o2) {
		// TODO Auto-generated method stub
		if(o1.getRollNo()>o2.getRollNo())
		{
			return 1; 
		}else if(o1.getRollNo()<o2.getRollNo())
		{
	return -1;
	}
		else 
	return 0;
	}
	

}
