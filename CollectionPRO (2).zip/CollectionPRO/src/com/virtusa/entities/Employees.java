package com.virtusa.entities;

public class Employees implements Comparable<Employees>{
	
	private int employeeId;
	private String firstName;
	private String lastName;
	private double salary;
	
	public Employees() {}
	
	public Employees(int employeeId,String firstName,String lastName,double salary) {
		
		this.employeeId=employeeId;
		this.firstName=firstName;
		this.lastName=lastName;
		this.salary=salary;
	}
	
	public int getEmployeeId(){
		return employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	
	public String getLastName() {
		return lastName;
	}


	public double getSalary() {
		return salary;
	}

	@Override
	public String toString() {
		StringBuilder builder=new StringBuilder();
		builder.append("Employee Id:"+employeeId+"\n");
		builder.append("Employee First Name:"+firstName+"\n");
		builder.append("Employee Last Name:"+lastName+"\n");
		builder.append("Employee Salary:"+salary+"\n");
		return builder.toString();
		
	}
	@Override
	public boolean equals(Object o){
		
		if(o instanceof Employees && o!=null) {
			
			Employees e2=(Employees)o;
			if(this.employeeId==e2.employeeId && this.firstName.equals(e2.firstName) && this.lastName.equals(e2.lastName) && this.salary==e2.salary) {
				return true;
			}
		}
		return false;
	}
	@Override
	public int hashCode(){
		return employeeId^firstName.hashCode()^lastName.hashCode()^(int)salary;
		
	}

	@Override
	public int compareTo(Employees o) {
		// TODO Auto-generated method stub
		if(this.employeeId>o.employeeId) {
			return 1;
		} else if(this.employeeId<o.employeeId) {
			return -1;
		}
		return 0;
	}

	

}
