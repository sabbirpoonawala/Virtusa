package com.virtusa.entities;

public class Student {
	
	private int rollNo;
	private String name;
	private double marks1;
	private double marks2;
	private double marks3;
	public Student() {}
	
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getMarks1() {
		return marks1;
	}
	public void setMarks1(double marks1) {
		this.marks1 = marks1;
	}
	public double getMarks2() {
		return marks2;
	}
	public void setMarks2(double marks2) {
		this.marks2 = marks2;
	}
	public double getMarks3() {
		return marks3;
	}
	public void setMarks3(double marks3) {
		this.marks3 = marks3;
	}
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + ", marks1=" + marks1 + ", marks2=" + marks2
				+ ", marks3=" + marks3 + ", getRollNo()=" + getRollNo() + ", getName()=" + getName() + ", getMarks1()="
				+ getMarks1() + ", getMarks2()=" + getMarks2() + ", getMarks3()=" + getMarks3() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	

}
