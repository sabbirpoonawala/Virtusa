package com.virtusa.list;

import java.util.ArrayList;
import java.util.List;

public class GenericsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Before Java 5
		
		//one developer creates list
		//unchecked
		List heteroList=new ArrayList();
		heteroList.add("sabbir");
		heteroList.add(12);
		heteroList.add(23.5f);
		
		
		//another developer iterates list
		//unsafe can result into ClassCastException
		for(Object o:heteroList) {
			if(o instanceof String) {
			String strObj=(String)o;
			System.out.println(strObj);
			}
			if(o instanceof Integer) {
				Integer intrObj=(Integer)o;
				System.out.println(intrObj);
				}
			if(o instanceof Float) {
				Float floatObj=(Float)o;
				System.out.println(floatObj);
				}
			
		}
		
		
		
	}

}
