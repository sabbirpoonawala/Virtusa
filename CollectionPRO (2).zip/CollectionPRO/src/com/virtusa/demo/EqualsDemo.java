package com.virtusa.demo;

public class EqualsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1="hello";
		String str2="hello";
		
		if(str1==str2)
			System.out.println("str1==str2");
		
		String strobj1=new String("hello");
		String strobj2=new String("hello");
		if(strobj1==strobj2)
			System.out.println("strobj1==strobj2");
		if(strobj1.equals(strobj2))
			System.out.println("strobj1.equals(strobj2)");

		
		

	}

}
