package com.virtusa.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;

public class StoreImageDBDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File file=new File("C:\\IO\\DB.properties");
		
		
		Properties properties=new Properties();
		try(
		 InputStream is=new FileInputStream(file);		
				
		){
			
			properties.load(is);
			
		}catch(IOException e) {
			
		}
		
		try {
			Class.forName(properties.getProperty("driver"));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try(
		 InputStream is=new FileInputStream(new File("C:\\IO\\download.png"));
				Connection con=DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("username"),properties.getProperty("password"));
				
		){
			
			PreparedStatement st=
					con.prepareStatement("insert into ImageTable values(?,?)");
			
			st.setInt(1,1);
			st.setBlob(2, is);
			
			int rows=st.executeUpdate();
			if(rows>0)
				System.out.println("inserted");
			else
			System.out.println("not inserted");
			
			
		}catch(Exception e) {
			
		}
		
		
	}

}
