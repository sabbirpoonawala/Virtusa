package com.virtusa.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class SerializeEmployeeDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		Employee employee=new Employee();
		employee.setEmpId(101);
		employee.setEmpName("sabbir");
		employee.setEmpDesignation("trainer");
		employee.setEmpSalary(45000);
		
		File file=new File("C:\\IO\\employee.ser");
		OutputStream os=new FileOutputStream(file);
		ObjectOutputStream oos=new ObjectOutputStream(os);
		oos.writeObject(employee);
		os.close();
		
		
		
		

	}

}
