package com.virtusa.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAccessFileDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		File file5=new File("C:\\IO\\File5.txt");
		RandomAccessFile random=new RandomAccessFile(file5,"rw");
		String data="I love Java";
		random.seek(10);
		random.writeBytes(data);
	    random.close();
	}

}
