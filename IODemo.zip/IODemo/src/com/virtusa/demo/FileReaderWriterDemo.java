package com.virtusa.demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

public class FileReaderWriterDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File file3=new File("C:\\IO\\file3.txt");
		File file4=new File("C:\\IO\\file4.txt");
		
		try(
			
				Reader reader=new FileReader(file3);
				BufferedReader buffer=new BufferedReader(reader);
				
				Writer writer=new FileWriter(file4);
			){
			
			String data=null;
			while((data=buffer.readLine())!=null) {
				writer.write(data);
			}
			
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		

	}

}
