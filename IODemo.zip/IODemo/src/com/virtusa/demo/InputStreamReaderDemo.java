package com.virtusa.demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class InputStreamReaderDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		InputStreamReader ir=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(ir);
		System.out.print("Please Enter Salary");
		double salary=Double.parseDouble(br.readLine());
		double tax=salary*0.01;
		System.out.println("Tax:"+tax);

	}

}
