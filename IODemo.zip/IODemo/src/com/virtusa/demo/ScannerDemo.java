package com.virtusa.demo;

import java.util.Scanner;

public class ScannerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.print("Please enter salary:");
		if(sc.hasNextDouble()) {
			double salary=sc.nextDouble();
			double tax=salary*0.01;
			System.out.println("Tax:"+tax);
			
		}else {
			sc.close();
			throw new RuntimeException("Invalid salary");
		}
		sc.close();
	}

}
