package com.virtusa.view;

public class StudentView {
	
	public void mainStudentView() {
		
		System.out.println("=======Student View======");
	}

}
