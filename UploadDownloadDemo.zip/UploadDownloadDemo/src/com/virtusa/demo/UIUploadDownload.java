package com.virtusa.demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class UIUploadDownload {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner=new Scanner(System.in);
		System.out.println("1.upload");
		System.out.println("2.download");
		System.out.print("Option:");
		
		int option=scanner.nextInt();
		if(option==1) {
			
			System.out.print("File Name:");
			String fileName=scanner.next();
			System.out.print("File path:");
			String path=scanner.next();
			File file=new File(path);
			try {
				Reader reader=new FileReader(file);
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
				PreparedStatement st=
						con.prepareStatement("insert into FileTable values(?,?,?)");
				st.setInt(1, 2);
				st.setString(2, fileName);
				st.setCharacterStream(3, reader);
				

				int rows=st.executeUpdate();
				if(rows>0)
					System.out.println("File uploaded successfully");
				else
					System.out.println("File upload failed");
				
			} catch (FileNotFoundException | ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}
		if(option==2) {
			
			System.out.print("File Id:");
			int fileId=scanner.nextInt();
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
				PreparedStatement st=
						con.prepareStatement("select file_Name,file_data from FileTable where file_Id=?");
				st.setInt(1, fileId);
				ResultSet rs=st.executeQuery();
				Reader reader=null;
				String fileName=null;
				while(rs.next()) {
					fileName=rs.getString("file_name");
					reader=rs.getCharacterStream("file_data");
				}
				File file=new File("c:\\virtusa\\download\\"+fileName);
				file.createNewFile();
			    Writer writer=new FileWriter(file);
			   int k=0;
			   BufferedReader br=new BufferedReader(reader);
			   String data=null;
			   while((data=br.readLine())!=null) {
				   writer.write(data);
			   }
			   writer.close();
			} catch (SQLException |  IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
			
		}
	
		
		
	}

}
