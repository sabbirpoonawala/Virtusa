package com.virtusa.demo;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

public class MainDemo {
	
	public List<String> getNames(){
		List<String> listString=new ArrayList<>();
		listString.add("sabbir");
		listString.add("amit");
		listString.add("sumeet");
		return listString;
	}

	static Logger log = Logger.getLogger(MainDemo.class.getName());
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BasicConfigurator.configure();
		log.info("Logger configured successfully");
		log.info("Main method started");
		
		MainDemo md=new MainDemo();
		log.debug("getNames() returned list==>"+md.getNames());
		try {
		int c=1/0;
		}catch(ArithmeticException e) {
			log.error("Exception occured"+e.getMessage());
		}

	}

}
