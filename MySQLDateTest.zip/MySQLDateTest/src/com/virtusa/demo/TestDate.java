package com.virtusa.demo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.chrono.Era;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

public class TestDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner=new Scanner(System.in);
		System.out.print("Dob (YYYY-MM-DD):");
		String date=scanner.next();
		StringTokenizer st=new StringTokenizer(date,"-");
		List<String> dob=new ArrayList<>();
		while(st.hasMoreTokens()) {
			
			String token=st.nextToken();
			dob.add(token);
		}

		int year=Integer.parseInt(dob.get(0));
		int month=Integer.parseInt(dob.get(1));
		int day=Integer.parseInt(dob.get(2));
		
		LocalDate localDate=LocalDate.of(year,month,day);
		System.out.println(localDate);
		//YYYY-MM-DD 
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
			PreparedStatement stm=conn.prepareStatement("insert into DateSample values(?,?)");
			stm.setInt(1, 1);
			stm.setDate(2, Date.valueOf(localDate));
			int rows=stm.executeUpdate();
			System.out.println("rows:"+rows);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
